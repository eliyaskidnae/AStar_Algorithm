
How to run the code 

1. python .\A_star.py vertices_file_path  visibility_file_path grid_map_path start.x start.y goal.x goal.y
   E.g : python .\A_star.py .\map\env_1.csv .\map\visibility_graph_env_1.csv .\gridMap\map3.png 50 90 375 375 

2. python .\Astar_grid.py  grid_map_path  start.x start.y goal.x goal.y 
   E.g : python .\Astar_grid.py .\gridMap\map3.png 50 90 375 375